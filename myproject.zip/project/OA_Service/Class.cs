﻿using System;

namespace OA_Service
{
    public class Class
    {
    }
}
