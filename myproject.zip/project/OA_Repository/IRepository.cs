﻿using Microsoft.EntityFrameworkCore;
using Microsoft.WindowsAzure.MediaServices.Client;
using Nest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OA_DataAccess;

namespace OA_Repository
{
    public class Repository<T> : IRepository<T> where T : BaseEntity
    {
        private readonly ApplicationContext context;
        private readonly DbSet<T> entities;

        public T Settings { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public object DelegateSettings => throw new NotImplementedException();

        public string Type => throw new NotImplementedException();

        public Repository(ApplicationContext context)
        {
            this.context = context;
           // entities = context.Set<T>();
        }

        public Repository()
        {
        }

        public IEnumerable<T> GetAll()
        {
            return entities.AsEnumerable();
        }
        public T Get(int id)
        {
            return entities.SingleOrDefault(p => p.ProductId == id);
        }
    }
}

