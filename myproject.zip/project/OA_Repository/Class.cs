﻿using System;

namespace OA_Repository
{
    public class Class
    {
    }
}
