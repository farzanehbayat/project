﻿namespace OA_DataAccess
{
    public class ProductDetails
    {
        public object Product { get; internal set; }
    }
}