﻿using System;

namespace OA_DataAccess
{
    public class Class
    {
    }
}
