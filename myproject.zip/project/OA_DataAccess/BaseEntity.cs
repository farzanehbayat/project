﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OA_dataAccess
{
    class BaseEntity
    {
        public int ProductId { get; set; }
  
    }
}
